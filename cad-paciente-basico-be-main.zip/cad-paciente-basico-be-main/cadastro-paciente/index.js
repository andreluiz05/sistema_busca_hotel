const mongoose = require('mongoose');

// Conectar ao MongoDB
mongoose.connect('mongodb+srv://wagnerdaniell06:iC0SHlLcrEb602NU@cluster0.c8fsr.mongodb.net/', {
    serverSelectionTimeoutMS: 300000
})
.then(() => {
    console.log('Conexão com o MongoDB estabelecida com sucesso!');
})
.catch((err) => {
    console.error('Erro ao conectar com o MongoDB:', err);
});

// Definir o schema do paciente
const pacienteSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    cpf: { type: String, required: true, unique: true },
    dataNascimento: { type: Date, required: true },
    email: { type: String, required: true },
    telefone: { type: String, required: true }
});

// Criar o modelo de paciente
const Paciente = mongoose.model('Paciente', pacienteSchema);

// Função para salvar um paciente no banco de dados
async function salvarPaciente(dadosPaciente) {
    try {
        const paciente = new Paciente(dadosPaciente);
        await paciente.save();
        console.log('Paciente salvo com sucesso!', paciente);
    } catch (err) {
        console.error('Erro ao salvar paciente:', err);
    }
}

// Exemplo de dados de paciente a serem salvos
const dadosPaciente = {
    nome: 'Maria da Silva',
    cpf: '12345612300',
    dataNascimento: new Date('1990-05-20'),
    email: 'maria.silva@gmail.com',
    telefone: '(11) 91234-5678'
};

// Salvar o paciente
salvarPaciente(dadosPaciente);
